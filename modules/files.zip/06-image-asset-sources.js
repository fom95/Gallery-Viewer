/*
 * 06-image-asset-sources.js
 *
 * The pluggable "image source" layer: resolves a thumb/medium/full URL
 * to an actual displayable asset, for either plain URLs (fetch + Cache
 * API) or Telegram file IDs (chunked download). This is the extension
 * point for adding new import sources later.
 */

const imageAssetCache = new WeakMap();

const imageResponseCacheName = "gallery-image-assets-v1";


async function blobURLFromResponse(response, assets, key) {
    if (!response || !response.ok)
        return null;
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    assets[key] = url;
    return url;
}


async function resolveCachedURL(url, image, resolution, isActive) {
    if (!url)
        return null;

    let assets = imageAssetCache.get(image);
    if (!assets) {
        assets = {};
        imageAssetCache.set(image, assets);
    }
    if (assets[resolution])
        return assets[resolution];

    const cacheKey = `https://gallery-image.invalid/url/${resolution}/${encodeURIComponent(url)}`;
    let cache = null;

    try {
        if (window.caches) {
            cache = await caches.open(imageResponseCacheName);
            const cached = await cache.match(cacheKey);
            if (cached)
                return blobURLFromResponse(cached, assets, resolution);
        }
    } catch (error) {
        console.debug("[IMAGE CACHE] Cache lookup failed", {
            resolution,
            url,
            error
        });
    }

    let response;
    try {
        response = await fetch(url, {cache: "force-cache"});
    } catch (error) {
        console.debug("[IMAGE FETCH] Fetch failed", {
            resolution,
            url,
            errorName: error?.name,
            errorMessage: error?.message
        });
        return null;
    }

    if (isActive && !isActive())
        return null;

    if (!response.ok) {
        console.debug("[IMAGE FETCH] Server returned an error", {
            resolution,
            url,
            status: response.status,
            statusText: response.statusText
        });
        return null;
    }

    try {
        if (cache)
            await cache.put(cacheKey, response.clone());
    } catch (error) {
        console.debug("[IMAGE CACHE] Cache store failed", {
            resolution,
            url,
            error
        });
    }

    try {
        return await blobURLFromResponse(response, assets, resolution);
    } catch (error) {
        console.debug("[IMAGE FETCH] Response-to-Blob failed", {
            resolution,
            url,
            errorName: error?.name,
            errorMessage: error?.message
        });
        return null;
    }
}


const imageSources = {
    url: {
        resolve: async (image, resolution, isActive) =>
            resolveCachedURL(getImageURLs(image)[resolution], image, resolution, isActive)
    },
    telegram: {
        resolve: async (image, resolution, isActive) => {
            const key = resolution === "thumb" ? "thumb" : "full";
            let assets = imageAssetCache.get(image);
            if (!assets) {
                assets = {};
                imageAssetCache.set(image, assets);
            }
            if (assets[key])
                return assets[key];

            const fileID = resolution === "thumb"
                ? image.telegramThumbnailFileID
                : image.telegramFileID;
            if (!fileID || !window.telegramClient)
                return null;

            const cacheKey = `https://gallery-image.invalid/telegram/${encodeURIComponent(fileID)}/${key}`;
            try {
                if (window.caches) {
                    const cache = await caches.open(imageResponseCacheName);
                    const cached = await cache.match(cacheKey);
                    if (cached)
                        return blobURLFromResponse(cached, assets, key);
                }
            } catch {}

            const chunks = [];
            for await (const chunk of window.telegramClient.download(fileID, {
                chunkSize: key === "thumb" ? 64 * 1024 : 256 * 1024
            })) {
                if (isActive && !isActive())
                    return null;
                chunks.push(chunk);
            }
            if (isActive && !isActive())
                return null;

            const blob = new Blob(chunks, {type: image.mimeType || "image/jpeg"});
            const url = URL.createObjectURL(blob);
            assets[key] = url;

            try {
                if (window.caches) {
                    const cache = await caches.open(imageResponseCacheName);
                    await cache.put(cacheKey, new Response(blob, {
                        headers: {"Content-Type": blob.type || "image/jpeg"}
                    }));
                }
            } catch {}

            return url;
        }
    }
};


async function resolveImageAsset(item, resolution, isActive) {
    if (!item?.image)
        return null;
    const source = imageSources[item.source] || imageSources.url;
    return source.resolve(item.image, resolution, isActive);
}


function openTemporaryAlbumFromURL(url) {

    if (!url)
        return;

    const query =
        getAlbumQuery(
            url.trim()
        );

    if (!query) {

        alert("No album query was found in that URL.");

        return;

    }

    const album =
        createQueryAlbum(query);

    const id =
        generateAlbumID(album.name);

    album.id =
        id;

    album.temporary =
        true;

    currentTemporaryAlbumID =
        id;

    saveTemporaryAlbum(album);

    history.pushState(
        null,
        "",
        "?=" +
        encodeURIComponent(id)
    );

    loadAlbum(album, false);

    showAlbumButtons(true);

}
