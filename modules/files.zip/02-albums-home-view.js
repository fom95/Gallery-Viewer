/*
 * 02-albums-home-view.js
 *
 * Renders the home grid of albums, refreshes the "My Albums" list from
 * localStorage, and builds each album's tag summary.
 */

async function showAlbums() {

    document.getElementById("regenerateAlbum").style.display =
        "none";

    document.getElementById("tagBar").style.display =
        "none";

    document.getElementById("tagToggle").style.display =
        "none";

    document.getElementById("pageName").textContent =
        "ImgBB Galleries";

    document.title =
        "Gallery Viewer";

    const currentQuery =
        window.location.search;

    if (
        !currentQuery.startsWith("?@")
    ) {

        history.replaceState(
            null,
            "",
            window.location.pathname
        );

    }

    isQueryAlbum =
        false;

    currentAlbum =
        null;

    stopThumbnailLoading();

    thumbnailItems =
        [];

    thumbnailQueue =
        [];

    if (!albums.length) {

        await reloadAlbums();

    }
    else {

        refreshSavedAlbums();

    }

    document.getElementById("backButton").style.display =
        "none";

    document.getElementById("saveButton").style.display =
        "none";

    const gallery =
        document.getElementById("gallery");

    gallery.innerHTML =
        "";

    if (!albums.length) {

        gallery.textContent =
            "No data loaded.";

        return;

    }

    albums.forEach(
        album => {

            const isTelegram =
                typeof album.url === "string" &&
                album.url.startsWith("tg://chat/");

            let cover =
                null;

            if (
                !isTelegram &&
                album.images &&
                album.images.length
            ) {

                cover =
                    album.images[
                        Math.floor(
                            Math.random() *
                            album.images.length
                        )
                    ];

            }

            const card =
                document.createElement("div");

            card.className =
                "album";

            const img =
                document.createElement("img");

            if (
                !isTelegram &&
                cover &&
                cover.thumb &&
                cover.thumb.url
            ) {

                img.src =
                    cover.thumb.url;

            }

            if (
                isTelegram
            ) {

                img.style.visibility =
                    "hidden";

            }

            const title =
                document.createElement("div");

            title.textContent =
                album.name;

            card.appendChild(img);

            card.appendChild(title);

            card.onclick =
                () => loadAlbum(album);

            if (
                isTelegram
            ) {

                const exportBtn =
                    document.createElement("button");

                exportBtn.className =
                    "album-export";

                exportBtn.textContent =
                    "↗";

                exportBtn.title =
                    "Copy Telegram album record";

                exportBtn.onclick =
                    async (e) => {

                        e.stopPropagation();

                        try {

                            if (
                                album._telegramLoadPromise
                            ) {

                                await album._telegramLoadPromise;

                            }
                            else {

                                await loadTelegramAlbum(album);

                            }

                            if (
                                !album._telegramMessageIDs ||
                                !album._telegramMessageIDs.length
                            ) {

                                alert("No Telegram image messages were found.");

                                return;

                            }

                            const match =
                                album.url.match(
                                    /^tg:\/\/chat\/(-?\d+)/
                                );

                            if (!match) {

                                alert("Invalid Telegram album URL.");

                                return;

                            }

                            const chatId =
                                match[1];

                            const coverID =
                                album._telegramCoverMessageID ||
                                album._telegramMessageIDs[0];

                            const messageIDs =
                                album._telegramMessageIDs.join(",");

                            const id =
                                generateAlbumID(album.name);

                            const js =
                                `,
	{
		id: "${id.replace(
							/"/g,
							'\\"'
						)}",
		name: "${album.name.replace(
							/"/g,
							'\\"'
						)}",
		url: \`
		tg://chat/${chatId}?cover=${coverID}&messages=${messageIDs}
		\`.trim(),
		tags: ${JSON.stringify(album.tags || [])}
	}`;

                            navigator.clipboard
                                .writeText(js)
                                .then(
                                    () => {

                                        alert("Copied Telegram album entry!");

                                    }
                                )
                                .catch(
                                    () => {

                                        prompt(
                                            "Copy this:",
                                            js
                                        );

                                    }
                                );

                        }
                        catch (error) {

							alert(
								"Failed to load Telegram album data:\n\n" +
								(
									error &&
									error.message
										? error.message
										: String(error)
								)
							);

						}

                    };

                card.appendChild(exportBtn);

            }

            if (
                album.storage
            ) {

                const deleteBtn =
                    document.createElement("button");

                deleteBtn.className =
                    "album-delete";

                deleteBtn.textContent =
                    "×";

                deleteBtn.title =
                    album.edited
                        ? "Delete local edits"
                        : "Remove saved album";

                if (
                    album.edited
                ) {

                    deleteBtn.classList.add("album-delete-edited");

                }

                deleteBtn.onclick =
                    (e) => {

                        e.stopPropagation();

                        let saved =
                            JSON.parse(
                                localStorage.getItem("savedAlbums") || "[]"
                            );

                        saved =
                            saved.filter(
                                savedAlbum =>
                                    savedAlbum.id !==
                                    album.id
                            );

                        localStorage.setItem(
                            "savedAlbums",
                            JSON.stringify(saved)
                        );

                        showAlbums();

                    };

                card.appendChild(deleteBtn);

                if (
                    album.edited
                ) {

                    const exportBtn =
                        document.createElement("button");

                    exportBtn.className =
                        "album-export";

                    exportBtn.textContent =
                        "↗";

                    exportBtn.title =
                        "Copy to albums.js";

                    exportBtn.onclick =
                        (e) => {

                            e.stopPropagation();

                            const query =
                                createAlbumQuery(album);

                            const id =
                                generateAlbumID(album.name);

                            const js =
                                `,
	{
		id: "${id.replace(
							/"/g,
							'\\"'
						)}",
		name: "${album.name.replace(
							/"/g,
							'\\"'
						)}",
		url: \`
		?${query}
		\`.trim(),
		tags: ${JSON.stringify(album.tags || [])}
	}`;

                            navigator.clipboard
                                .writeText(js)
                                .then(
                                    () => {

                                        alert("Copied album.js entry!");

                                    }
                                )
                                .catch(
                                    () => {

                                        prompt(
                                            "Copy this:",
                                            js
                                        );

                                    }
                                );

                        };

                    card.appendChild(exportBtn);

                }

            }

            gallery.appendChild(card);

            if (
                isTelegram &&
                window.telegramClient
            ) {

                album._telegramCoverPromise =
					loadTelegramAlbumCover(album);

				album._telegramCoverPromise
					.then(
						result => {

							img.src =
								result.url;

							img.style.visibility =
								"visible";

						}
					)
					.catch(
						error => {

						}
					);

            }

        }
    );

    const addCard =
        document.createElement("div");

    addCard.className =
        "album album-add";

    const addImage =
        document.createElement("div");

    addImage.className =
        "album-add-image";

    addImage.textContent =
        "+";

    const addTitle =
        document.createElement("div");

    addTitle.textContent =
        "Add New";

    addCard.appendChild(addImage);

    addCard.appendChild(addTitle);

    addCard.onclick =
        () => {

            openAlbumInput();

        };

    gallery.appendChild(addCard);

    applyGalleryLayout(false);

    document.documentElement.classList.remove("pageLoading");

    showAddImageButton();
}


function refreshSavedAlbums() {

    for (
        let i = albums.length - 1;
        i >= 0;
        i--
    ) {

        if (
            albums[i].storage
        ) {

            albums.splice(
                i,
                1
            );

        }

    }

    const saved =
        JSON.parse(
            localStorage.getItem("savedAlbums") || "[]"
        );

    saved.forEach(
        album => {

            albums.push({

                ...album,

                tags:
                    album.tags ||
                    [],

                storage:
                    true

            });

        }
    );

}


function returnToAlbums() {

    if (
        currentTemporaryAlbumID
    ) {

        deleteTemporaryAlbum(currentTemporaryAlbumID);

        currentTemporaryAlbumID =
            null;

    }

    showAlbums();

}


async function buildAlbumTags(album) {

    const tagSet = new Set();

    album.images.forEach(img => {

        (img.tags || []).forEach(tag => {
            tagSet.add(tag);
        });

    });

    album.tags = [...tagSet];

    buildTagList(album.tags);
}
