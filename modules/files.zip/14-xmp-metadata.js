/*
 * 14-xmp-metadata.js
 *
 * Reads XMP metadata (tags) out of raw image file bytes.
 */

const XMP = {

    getData: function (img, callback) {

        fetch(img.src)
        .then(r => r.arrayBuffer())
        .then(buffer => {

            const xmpString = findXMP(buffer);

            if (!xmpString) {
                callback.call(img, null);
                return;
            }

            img.xmpraw = xmpString;
            img.xmp = parseXMP(xmpString);
            img.xmptags = createXMPShortcuts(img.xmp);

            callback.call(img, img.xmp);

        });

    }

};


function findXMP(buffer) {

    const bytes = new Uint8Array(buffer);

    const text = new TextDecoder("utf-8")
        .decode(bytes);

    const start = text.indexOf("<x:xmpmeta");

    if (start === -1)
        return null;

    const end = text.indexOf("</x:xmpmeta>", start);

    if (end === -1)
        return null;

    return text.substring(
        start,
        end + "</x:xmpmeta>".length);

}


function parseXMP(xmpString) {

    const xml = new DOMParser()
        .parseFromString(xmpString, "application/xml");

    function cleanName(name) {

        return name.includes(":")
         ? name.split(":")[1]
         : name;

    }

    function addChild(obj, key, value) {

        if (obj[key] === undefined)
            obj[key] = value;
        else if (Array.isArray(obj[key]))
            obj[key].push(value);
        else
            obj[key] = [obj[key], value];

    }

    function parseNode(node) {

        const obj = {};

        for (const attr of node.attributes || []) {

            obj[cleanName(attr.name)] =
                attr.value;

        }

        if (node.children.length === 0) {

            const text = node.textContent.trim();

            return text || obj;

        }

        for (const child of node.children) {

            addChild(
                obj,
                cleanName(child.nodeName),
                parseNode(child));

        }

        return obj;

    }

    return parseNode(xml.documentElement);

}


function createXMPShortcuts(xmp) {

    const desc =
        xmp.RDF?.Description || {};

    return {

        subject:
        Array.isArray(desc.subject?.Bag?.li)
         ? desc.subject.Bag.li
         : desc.subject?.Bag?.li
         ? [desc.subject.Bag.li]
         : [],

        dimensions:
        desc.Regions?.AppliedToDimensions || null,

        faces:
        (() => {

            const faces =
                desc.Regions?.RegionList?.Bag?.li || [];

            const list =
                Array.isArray(faces)
                 ? faces
                 : [faces];

            return list.map(f => {

                const d =
                    f.Description || f;

                return {
                    name: d.Name,
                    type: d.Type,
                    area: d.Area
                };

            });

        })()

    };

}


function getAllTags() {

    const tags = new Set();

    albums.forEach(album => {

        (album.tags || []).forEach(tag => {
            tags.add(tag.toLowerCase());
        });

    });

    return [...tags];

}
