/*
 * 04-telegram-import.js
 *
 * Everything Telegram: connecting the client, bulk-importing a chat's
 * photos into an album, loading a chat's cover image, and the chat
 * picker UI. This is one of the two current bulk-import sources.
 */

async function loadTelegramAlbum(album) {

    if (!window.telegramClient) {

        throw new Error(
            "Telegram client is not initialized."
        );

    }

    const client =
        window.telegramClient;


    /*
     * Parse Telegram album URL.
     */

    const match =
        album.url.match(
            /^tg:\/\/chat\/(-?\d+)(?:\?(.+))?$/
        );

    if (!match) {

        throw new Error(
            "Invalid Telegram album URL: " +
            album.url
        );

    }


    const chatId =
        Number(match[1]);

    const optionString =
        match[2] ||
        "";

    const options =
        new URLSearchParams(
            optionString
        );

    const coverMessageID =
        options.get("cover");

    const messageString =
        options.get("messages");


    let requestedMessageIDs =
        [];

    if (messageString) {

        requestedMessageIDs =
            messageString
                .split(",")
                .map(
                    id =>
                        Number(id)
                )
                .filter(
                    id =>
                        Number.isInteger(id) &&
                        id > 0
                );

    }


    /*
     * Find the chat.
     */

    let chat =
        null;

    if (
        Array.isArray(
            window.telegramChats
        )
    ) {

        const found =
            window.telegramChats.find(
                item =>
                    item &&
                    item.chat &&
                    String(
                        item.chat.id
                    ) ===
                    String(chatId)
            );

        if (found) {

            chat =
                found.chat;

        }

    }


    if (!chat) {

        const chats =
            await client.getChats({
                limit:
                    500
            });

        window.telegramChats =
            chats;

        const found =
            chats.find(
                item =>
                    item &&
                    item.chat &&
                    String(
                        item.chat.id
                    ) ===
                    String(chatId)
            );

        if (found) {

            chat =
                found.chat;

        }

    }


    if (!chat) {

        throw new Error(
            "Telegram chat was not found: " +
            chatId
        );

    }


    /*
     * Retrieve the requested messages.
     *
     * There is deliberately NO retry loop here.
     *
     * If Telegram/MTKruto throws, this function throws once
     * and loadAlbum() handles the error once.
     */

    let messages =
        [];

    if (
        requestedMessageIDs.length
    ) {

        messages =
            await client.getMessages(
                chat.id,
                requestedMessageIDs
            );

    }
    else {

        messages =
            await client.getHistory(
                chat.id,
                {
                    limit:
                        100
                }
            );

    }


    /*
     * Restore the exact order from the URL.
     */

    if (
        requestedMessageIDs.length
    ) {

        const messageMap =
            new Map();

        for (
            const message of
            messages
        ) {

            if (
                message &&
                Number.isInteger(
                    message.id
                )
            ) {

                messageMap.set(
                    message.id,
                    message
                );

            }

        }

        messages =
            requestedMessageIDs
                .map(
                    messageID =>
                        messageMap.get(
                            messageID
                        )
                )
                .filter(
                    message =>
                        !!message
                );

    }


    /*
     * Process every retrieved message.
     *
     * DO NOT filter by message._ here.
     *
     * MTKruto's high-level objects returned by getMessages()
     * expose their media directly as properties such as:
     *
     *     message.photo
     *     message.document
     *     message.video
     */

    const images =
        [];


    let photoCount =
        0;

    let documentCount =
        0;

    let videoCount =
        0;

    let noMediaCount =
        0;

    let noFileIDCount =
        0;


    for (
        const message of
        messages
    ) {

        if (!message) {

            continue;

        }


        let media =
            null;

        let fileID =
            null;

        let mimeType =
            "";

        let fileName =
            "";

        let width =
            null;

        let height =
            null;

        let mediaType =
            "media";


        /*
         * -----------------------------------------------
         * PHOTO
         * -----------------------------------------------
         */

        if (
            message.photo &&
            typeof message.photo.fileId ===
                "string" &&
            message.photo.fileId
        ) {

            media =
                message.photo;

            fileID =
                message.photo.fileId;

            mimeType =
                "image/jpeg";

            width =
                message.photo.width ??
                null;

            height =
                message.photo.height ??
                null;

            mediaType =
                "photo";

            photoCount++;

        }


        /*
         * -----------------------------------------------
         * DOCUMENT
         * -----------------------------------------------
         *
         * Do NOT restrict this to image/*.
         *
         * This allows future video/file handling.
         */

        else if (
			message.document &&
			(
				message.document.mimeType ||
				message.document.mime_type ||
				""
			).startsWith("image/")
		) {

			media =
				message.document;

			if (
				typeof media.fileId ===
					"string" &&
				media.fileId
			) {

				fileID =
					media.fileId;

			}

			mimeType =
				media.mimeType ||
				media.mime_type ||
				"";

			fileName =
				media.fileName ||
				media.file_name ||
				"";

			width =
				media.width ??
				null;

			height =
				media.height ??
				null;

			mediaType =
				"document";

			documentCount++;

		}

        /*
         * -----------------------------------------------
         * VIDEO
         * -----------------------------------------------
         */

        else if (
            message.video
        ) {

            media =
                message.video;

            if (
                typeof media.fileId ===
                    "string" &&
                media.fileId
            ) {

                fileID =
                    media.fileId;

            }

            mimeType =
                media.mimeType ||
                media.mime_type ||
                "video/mp4";

            fileName =
                media.fileName ||
                media.file_name ||
                "";

            width =
                media.width ??
                null;

            height =
                media.height ??
                null;

            mediaType =
                "video";

            videoCount++;

        }


        /*
         * No recognized downloadable media.
         *
         * This can simply be a text message, poll, service
         * message, etc.
         *
         * It was still checked; it just doesn't become an
         * image/gallery item.
         */

        if (!media) {

            noMediaCount++;

            continue;

        }


        /*
         * Recognized media but no usable MTKruto fileId.
         *
         * Do NOT put it into the album because that could
         * feed an invalid ID into the thumbnail retry system.
         */

        if (!fileID) {

            noFileIDCount++;

            console.warn(
                "Telegram media has no usable fileId; " +
                "skipping message " +
                message.id
            );

            continue;

        }


        /*
         * Create the album item.
         *
         * Every item here has a verified non-empty fileId.
         */

        images.push({

			source:
				"telegram",

			messageID:
				message.id,

			telegramFileID:
				fileID,

			telegramThumbnailFileID:
				fileID,

			mimeType:
				mimeType,

			fileName:
				fileName,

			width:
				width,

			height:
				height,

			tags:
				[],

			telegramMediaType:
				mediaType

		});
    }


    /*
     * Store media items.
     */

    album.images =
        images;


    /*
     * Determine cover.
     */

    let coverImage =
        null;

    if (
        coverMessageID
    ) {

        coverImage =
            images.find(
                image =>
                    String(
                        image.messageID
                    ) ===
                    String(
                        coverMessageID
                    )
            );

    }


    if (
        !coverImage &&
        images.length
    ) {

        coverImage =
            images[0];

    }


    /*
     * Store Telegram metadata.
     */

    album._telegramMessageIDs =
        images.map(
            image =>
                image.messageID
        );

    album._telegramCoverMessageID =
        coverImage
            ? coverImage.messageID
            : null;

    album._telegramLoaded =
        true;


    /*
     * One concise diagnostic.
     */

    console.log(
        "Telegram album loaded:",
        {
            chatId:
                chat.id,

            messagesChecked:
                messages.length,

            mediaItems:
                images.length,

            photos:
                photoCount,

            documents:
                documentCount,

            videos:
                videoCount,

            noMedia:
                noMediaCount,

            noFileID:
                noFileIDCount
        }
    );

}


async function initializeTelegramClient() {

    if (window.telegramClient) {

        return window.telegramClient;

    }

    if (
        !window.telegramAppId ||
        !window.telegramAppHash
    ) {

        return null;

    }

    if (
        !window.TelegramClient ||
        !window.TelegramStorageIndexedDB
    ) {

        throw new Error("MTKruto has not been loaded.");

    }

    const client =
        new window.TelegramClient({

            apiId:
                Number(window.telegramAppId),

            apiHash:
                window.telegramAppHash,

            storage:
                new window.TelegramStorageIndexedDB("telegram-browser-gallery")

        });

    window.telegramClient =
        client;

    await client.start({

        phone: async () => {

            const value =
                prompt("Enter your Telegram phone number:");

            if (value === null) {
                throw new Error("Telegram login cancelled.");
            }

            return value;

        },

        code: async () => {

            const value =
                prompt("Enter the Telegram login code:");

            if (value === null) {
                throw new Error("Telegram login cancelled.");
            }

            return value;

        },

        password: async () => {

            const value =
                prompt("Enter your Telegram 2FA password:");

            if (value === null) {
                throw new Error("Telegram login cancelled.");

            }

            return value;

        }

    });

    return client;
}


async function loadTelegramAlbumCover(album) {

    if (
        !window.telegramClient
    ) {
        throw new Error("Telegram client is not initialized.");
    }

    const client =
        window.telegramClient;

    const match =
        album.url.match(
            /^tg:\/\/chat\/(-?\d+)(?:\?(.+))?$/
        );

    if (!match) {
        throw new Error(
            "Invalid Telegram album URL: " +
            album.url
        );
    }

    const chatId =
        Number(match[1]);

    const optionString =
        match[2] ||
        "";

    const options =
        new URLSearchParams(optionString);

    const coverMessageID =
        options.get("cover");

    let chat =
        null;

    if (
        Array.isArray(window.telegramChats)
    ) {

        const found =
            window.telegramChats.find(
                item =>
                    item &&
                    item.chat &&
                    String(item.chat.id) ===
                    String(chatId)
            );

        if (found) {
            chat =
                found.chat;
        }

    }

    if (!chat) {

        const chats =
            await client.getChats();

        window.telegramChats =
            chats;

        const found =
            chats.find(
                item =>
                    item &&
                    item.chat &&
                    String(item.chat.id) ===
                    String(chatId)
            );

        if (found) {
            chat =
                found.chat;
        }

    }

    if (!chat) {
        throw new Error(
            "Telegram chat was not found: " +
            chatId
        );
    }

    let message = null;

    if (coverMessageID) {

        message =
            await client.getMessage(
                chat.id,
                Number(coverMessageID)
            );

    }
    else {

        const messages =
            await client.getHistory(
                chat.id,
                {
                    limit: 100
                }
            );

        message =
            messages.find(
                message =>
                    message &&
                    message.document &&
                    typeof message.document.mimeType ===
                        "string" &&
                    message.document.mimeType.startsWith("image/")
            );

    }

    if (
        !message ||
        !message.document
    ) {

        throw new Error("Telegram cover message is not an image.");

    }

    const fileDocument =
        message.document;

    const mimeType =
        fileDocument.mimeType ||
        "image/jpeg";

    let thumbnail =
        null;

    if (
        Array.isArray(fileDocument.thumbnails) &&
        fileDocument.thumbnails.length
    ) {

        thumbnail =
            fileDocument.thumbnails
                .slice()
                .sort(
                    (a, b) =>
                        (
                            (b.width || 0) *
                            (b.height || 0)
                        ) -
                        (
                            (a.width || 0) *
                            (a.height || 0)
                        )
                )[0];

    }

    if (!thumbnail) {

        throw new Error("Telegram cover has no thumbnail.");

    }

    const chunks =
        [];

    for await (
        const chunk of
        client.download(
            thumbnail.fileId,
            {
                chunkSize:
                    64 * 1024
            }
        )
    ) {

        chunks.push(chunk);

    }

    const blob =
        new Blob(
            chunks,
            {
                type:
                    mimeType
            }
        );

    const url =
        URL.createObjectURL(blob);

    return {
        url:
            url,

        messageID:
            message.id
    };
}


async function populateTelegramAlbumChats(select) {

    if (!select)
        return;

    if (
        !window.telegramClient
    ) {

        select.innerHTML = `
            <option value="">
                Telegram is not initialized
            </option>
        `;

        return;

    }

    try {

        let chats =
            Array.isArray(window.telegramChats)
                ? window.telegramChats
                : null;

        if (!chats) {

            chats =
                await window.telegramClient.getChats();

            window.telegramChats =
                chats;

        }

        const usedChatIDs =
            new Set();

        if (
            Array.isArray(albums)
        ) {

            albums.forEach(
                album => {

                    if (
                        !album ||
                        typeof album.url !== "string"
                    ) {
                        return;
                    }

                    const match =
                        album.url.match(
                            /^tg:\/\/chat\/(-?\d+)/
                        );

                    if (match) {

                        usedChatIDs.add(
                            String(match[1])
                        );

                    }

                }
            );

        }

        const availableChats =
            [];

        chats.forEach(
            item => {

                if (
                    !item ||
                    !item.chat
                ) {
                    return;
                }

                const chat =
                    item.chat;

                const chatID =
                    String(chat.id);

                if (
                    usedChatIDs.has(chatID)
                ) {

                    return;

                }

                const type =
                    String(
                        chat.type ||
                        ""
                    ).toLowerCase();

                if (
                    type === "private" ||
                    type === "user" ||
                    type === "bot"
                ) {

                    return;

                }

                availableChats.push(chat);

            }
        );

        availableChats.sort(
            (a, b) =>
                String(
                    a.title ||
                    a.username ||
                    a.id
                ).localeCompare(
                    String(
                        b.title ||
                        b.username ||
                        b.id
                    )
                )
        );

        select.innerHTML = `
            <option value="">
                Select Telegram chat
            </option>
        `;

        availableChats.forEach(
            chat => {

                const option =
                    document.createElement("option");

                option.value =
                    chat.id;

                option.textContent =
                    chat.title ||
                    chat.username ||
                    String(chat.id);

                select.appendChild(option);

            }
        );

        if (
            !availableChats.length
        ) {

            const option =
                document.createElement("option");

            option.value =
                "";

            option.textContent =
                "No unused Telegram chats";

            select.appendChild(option);

        }

    }
    catch (error) {

        select.innerHTML = `
            <option value="">
                Failed to load Telegram chats
            </option>
        `;

    }

}


async function openTemporaryTelegramAlbum(chatID) {

    if (!chatID) {
        return;
    }

    if (!window.telegramClient) {
        alert("Telegram client is not initialized.");
        return;
    }

    try {

        const client =
            window.telegramClient;

        /*
         * Find the selected chat.
         */

        let chat = null;

        if (Array.isArray(window.telegramChats)) {

            const found =
                window.telegramChats.find(
                    item =>
                        item &&
                        item.chat &&
                        String(item.chat.id) ===
                        String(chatID)
                );

            if (found) {
                chat = found.chat;
            }
        }

        if (!chat) {

            const chats =
                await client.getChats({
                    limit: 500
                });

            window.telegramChats =
                chats;

            const found =
                chats.find(
                    item =>
                        item &&
                        item.chat &&
                        String(item.chat.id) ===
                        String(chatID)
                );

            if (found) {
                chat = found.chat;
            }
        }

        if (!chat) {
            throw new Error(
                "Telegram chat was not found: " +
                chatID
            );
        }


        /*
         * Retrieve the ENTIRE chat history.
         *
         * Telegram gives us newest -> oldest.
         * offset_id walks backwards through the history.
         */

        const peer =
            await client.getInputPeer(
                chat.id
            );

        const allMessages =
            new Map();

        let offsetID = 0;

        while (true) {

            const result =
                await client.invoke({
                    _: "messages.getHistory",

                    peer,

                    offset_id:
                        offsetID,

                    offset_date:
                        0,

                    add_offset:
                        0,

                    limit:
                        100,

                    max_id:
                        0,

                    min_id:
                        0,

                    hash:
                        0n
                });

            const page =
                result &&
                Array.isArray(result.messages)
                    ? result.messages
                    : [];

            if (!page.length) {
                break;
            }

            let oldestID = null;

            for (const message of page) {

                if (
                    !message ||
                    message.id == null
                ) {
                    continue;
                }

                allMessages.set(
                    String(message.id),
                    message
                );

                if (
                    oldestID === null ||
                    BigInt(String(message.id)) <
                    BigInt(String(oldestID))
                ) {

                    oldestID =
                        message.id;
                }
            }

            if (oldestID === null) {
                break;
            }

            /*
             * Hard protection against a broken pagination
             * response causing an infinite loop.
             */

            if (
                offsetID !== 0 &&
                BigInt(String(oldestID)) >=
                BigInt(String(offsetID))
            ) {

                console.warn(
                    "Telegram history pagination stopped because " +
                    "the oldest message ID did not move backwards.",
                    {
                        previousOffsetID:
                            offsetID,

                        oldestID:
                            oldestID
                    }
                );

                break;
            }

            offsetID =
                oldestID;
        }


        /*
         * Oldest -> newest.
         */

        const messages =
            Array.from(
                allMessages.values()
            ).sort(
                (a, b) => {

                    const A =
                        BigInt(String(a.id));

                    const B =
                        BigInt(String(b.id));

                    if (A < B) {
                        return -1;
                    }

                    if (A > B) {
                        return 1;
                    }

                    return 0;
                }
            );


        /*
         * IMPORTANT:
         *
         * Every normal/user-created message is included.
         *
         * We deliberately do NOT inspect:
         *
         *     message.photo
         *     message.document
         *     message.video
         *     etc.
         *
         * here.
         *
         * The purpose of this list is to preserve actual
         * Telegram MESSAGE positions.
         *
         * Telegram service messages are excluded because
         * they are automatically generated and should not
         * consume a position.
         */

        const targetMessages =
            messages.filter(
                message =>
                    message &&
                    message._ === "message"
            );


        if (!targetMessages.length) {

            alert(
                "No user-created messages were found in this Telegram chat."
            );

            return;
        }


        const messageIDs =
            targetMessages.map(
                message =>
                    message.id
            );


        /*
         * First normal message is only an initial cover
         * candidate. loadTelegramAlbum() will replace this
         * with the first actual media item.
         */

        const coverMessageID =
            targetMessages[0].id;


        const telegramURL =
            "tg://chat/" +
            String(chat.id) +
            "?cover=" +
            encodeURIComponent(
                coverMessageID
            ) +
            "&messages=" +
            messageIDs
                .map(
                    id =>
                        encodeURIComponent(id)
                )
                .join(",");


        const album = {

            id:
                generateAlbumID(
                    chat.title ||
                    chat.username ||
                    "Telegram Album"
                ),

            name:
                chat.title ||
                chat.username ||
                "Telegram Album",

            url:
                telegramURL,

            tags:
                [],

            images:
                [],

            temporary:
                true,

            edited:
                false
        };


        /*
         * Debug information without flooding the console.
         */

        console.log(
            "Temporary Telegram album:",
            {
                chat:
                    chat.title ||
                    chat.username ||
                    chat.id,

                totalMessages:
                    messages.length,

                normalMessages:
                    targetMessages.length,

                serviceMessages:
                    messages.length -
                    targetMessages.length
            }
        );


        currentTemporaryAlbumID =
            album.id;

        saveTemporaryAlbum(
            album
        );


        history.pushState(
            null,
            "",
            "?=" +
            encodeURIComponent(
                album.id
            )
        );


        /*
         * IMPORTANT:
         *
         * Do not await a retrying background operation here.
         * loadAlbum() performs the normal one-time load.
         */

        await loadAlbum(
            album,
            false
        );

        showAlbumButtons(true);

    }
    catch (error) {

        console.error(
            "openTemporaryTelegramAlbum failed:",
            error
        );

        alert(
            "Failed to open Telegram album:\n\n" +
            (
                error &&
                error.message
                    ? error.message
                    : String(error)
            )
        );
    }
}
