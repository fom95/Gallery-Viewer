# Module split of script.js

This is your `script.js` cut into 20 files along its natural feature
boundaries. Nothing was rewritten — every top-level statement (each
`function`, `const`, `let`, and event-listener block) was verified,
mechanically, to appear exactly once across these files with nothing
missing, duplicated, or reordered in a way that changes behavior. It should
run identically to the original.

## How to include these

These are plain scripts, not ES modules — everything still lives in one
shared global scope, exactly like the original single file. That means:

- Include them with ordinary `<script src="...">` tags (no `type="module"`,
  no `defer`, no `async`).
- Include them **in the order listed below**. Order barely matters between
  most files (functions are just being defined), with **one exception**:
  `99-bootstrap.js` calls `initAlbums()` immediately, so it must load
  **last**, after every other file.

```html
<script src="modules/00-state-and-config.js"></script>
<script src="modules/01-album-routing-and-parsing.js"></script>
<script src="modules/02-albums-home-view.js"></script>
<script src="modules/03-temporary-albums-and-import-dialog.js"></script>
<script src="modules/04-telegram-import.js"></script>
<script src="modules/05-album-loading-and-render.js"></script>
<script src="modules/06-image-asset-sources.js"></script>
<script src="modules/07-thumbnail-loading-pipeline.js"></script>
<script src="modules/08-medium-loading-pipeline.js"></script>
<script src="modules/09-full-image-loader.js"></script>
<script src="modules/10-modal-viewer.js"></script>
<script src="modules/11-zoom-and-pan.js"></script>
<script src="modules/12-image-navigation-and-touch.js"></script>
<script src="modules/13-tag-filtering-and-gallery-layout.js"></script>
<script src="modules/14-xmp-metadata.js"></script>
<script src="modules/15-tag-search-and-suggestions.js"></script>
<script src="modules/16-tag-bar-state-and-center-return.js"></script>
<script src="modules/17-add-image-editor.js"></script>
<script src="modules/18-reload-albums-and-persistence.js"></script>
<script src="modules/99-bootstrap.js"></script>
```

Wherever your `<script src="script.js">` tag was, replace it with that
block, in that order.

## What's in each file

| File | Contents |
|---|---|
| `00-state-and-config.js` | Global state (current album/image, tag filters) and the gallery's responsive layout settings. |
| `01-album-routing-and-parsing.js` | Album ID generation, URL query parsing (`?query=`, `?gh=`, `?tg=`, `@paste`, `$album`, `=temp`), and `initAlbums()` — the startup router. |
| `02-albums-home-view.js` | The home grid of albums, the "My Albums" list, and per-album tag summaries. |
| `03-temporary-albums-and-import-dialog.js` | Unsaved temporary albums, and the "add album from a URL" dialog. |
| `04-telegram-import.js` | Telegram client setup, bulk-importing a chat's photos, cover images, and the chat picker. |
| `05-album-loading-and-render.js` | Loading an album and creating each image's thumbnail slot + data item. |
| `06-image-asset-sources.js` | The pluggable source layer that resolves thumb/medium/full URLs — the extension point for new import sources. |
| `07-thumbnail-loading-pipeline.js` | Progressive thumbnail queueing, prioritization, and retry/backoff for failures. |
| `08-medium-loading-pipeline.js` | Same, for medium-quality images. |
| `09-full-image-loader.js` | Full-resolution loading for the lightbox, plus zoom/resolution-switch tuning constants. |
| `10-modal-viewer.js` | Opening/closing the full-screen viewer. |
| `11-zoom-and-pan.js` | Pinch-zoom, pan, and resolution swapping while zoomed. |
| `12-image-navigation-and-touch.js` | Next/previous navigation, keyboard shortcuts, touch gestures, browser back/forward. |
| `13-tag-filtering-and-gallery-layout.js` | The tag filter bar and the responsive gallery grid layout. |
| `14-xmp-metadata.js` | Reading XMP tags out of image bytes. |
| `15-tag-search-and-suggestions.js` | The tag search box, autocomplete, and searching albums by tag. |
| `16-tag-bar-state-and-center-return.js` | Tag bar UI persistence and the "snap back to center" animation. |
| `17-add-image-editor.js` | The one-at-a-time "add image" editor, plus base64 URL helpers. |
| `18-reload-albums-and-persistence.js` | Loading albums from every source and saving edits back to storage. |
| `99-bootstrap.js` | The single line `initAlbums();`. Loads last. |

## Two things worth a look while you're in here

Splitting the file surfaced two pre-existing oddities (already present in
your original `script.js`, unchanged by this split — flagging them since
they're now much easier to spot):

1. **`getNextAvailableVisibleSlot` is defined twice** in
   `07-thumbnail-loading-pipeline.js` (once near the top, once further
   down). The second definition silently wins; the first is dead code.
   Worth checking whether the two versions actually did different things.
2. **`searchInput` has two separate `keydown` listeners** registered in
   `15-tag-search-and-suggestions.js`. Both fire on every keydown, which
   may be intentional (two independent concerns) or may be causing
   double-handling of some keys — worth a quick check.

## Why this split, not something more aggressive

I stuck to a mechanical, verified split — same functions, same order of
execution, same global variables — rather than also renaming things,
converting to modules/classes, or restructuring how pieces talk to each
other. That's a much bigger, riskier change to make blind (I can't run
this app in a browser to test it), so I kept this pass to "same behavior,
better organized," and left deeper refactors as a separate next step if
you want one.
